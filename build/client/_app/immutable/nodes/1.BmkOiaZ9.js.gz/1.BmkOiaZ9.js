import{E as o}from"../chunks/CQ_OKYWu.js";export{o as component};
