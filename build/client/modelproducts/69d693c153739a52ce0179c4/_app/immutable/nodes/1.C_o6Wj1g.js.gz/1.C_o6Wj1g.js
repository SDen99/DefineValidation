import{E as o}from"../chunks/XWJIT7Xq.js";export{o as component};
